/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package neededfiles;

/**
 *
 * @author PR-PC
 */
public class Courses {
        public String name,link,univ,spl,website;
    
    public Courses(String name,String univ,String link,String spl,String website){
    this.name = name;
    this.univ = univ;
    this.link = link;
    this.spl = spl;
    this.website = website;
    }
}

