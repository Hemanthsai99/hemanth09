# project_bi
How to run :
1. Import ItHappens directory in NetBeans 8.0 above version.
2. Download Scrapy tool and go to ws directory and run the following command:
 scrapy crawl cera && scrapy crawl edx 
3. Open web browser and go to localhost:8080/ItHappens .



