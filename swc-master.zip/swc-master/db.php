<?php 
set_time_limit(60000);
$connect = mysqli('localhost','root','','swc');
?>